package com.capgemini.batch.excel;

import org.springframework.batch.item.excel.RowMapper;
import org.springframework.batch.item.excel.support.rowset.RowSet;
import org.springframework.stereotype.Component;

import com.capgemini.model.Billing;
import com.capgemini.model.BillingDTO;
@Component
public class BillingExcelRowMapper implements RowMapper<BillingDTO> {

	@Override
	public BillingDTO mapRow(RowSet rowSet) throws Exception {
		BillingDTO bill = new BillingDTO();

		bill.setCustomerId((rowSet.getColumnValue(0)));
		bill.setCustomerName(rowSet.getColumnValue(1));
		bill.setRate(rowSet.getColumnValue(2));
		bill.setQty(rowSet.getColumnValue(3));
		bill.setCurrentBalance(rowSet.getColumnValue(4));
		bill.setOldBalance(rowSet.getColumnValue(5));
		bill.setTotal(rowSet.getColumnValue(6));
		bill.setState(rowSet.getColumnValue(7));
		bill.setArea(rowSet.getColumnValue(8));
		bill.setCity(rowSet.getColumnValue(9));
		bill.setMonth(rowSet.getColumnValue(10));
		bill.setYear(rowSet.getColumnValue(11));
		bill.setBillingDate(rowSet.getColumnValue(12));
		bill.setGstnId(rowSet.getColumnValue(13));

		return bill;
	}

}
