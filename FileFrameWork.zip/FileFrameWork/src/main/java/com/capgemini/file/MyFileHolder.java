package com.capgemini.file;

import java.io.Serializable;
import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name = "myFileHolder")
public class MyFileHolder implements Serializable {

	private static final long serialVersionUID = -4461272016331725832L;

	@Id
	@Column
	@GeneratedValue
	private long id;
	@Column
	private Blob file;

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Blob getFile() {
		return file;
	}
	public void setFile(Blob file) {
		this.file = file;
	}

	

	
}
