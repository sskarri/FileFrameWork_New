package com.capgemini.file;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.rowset.serial.SerialBlob; 

import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.batch.excel.ExcelFileToDatabaseJobLauncher;
import com.capgemini.model.RequestPojo;
import com.capgemini.pdf.ZipUtils;

@Component
@RestController
public class FileController {

	
	
	@Autowired
	FileRepository fileRepository;
	

	
	@Autowired
	ExcelFileReader excelFileReader;
	
	@Autowired
	ExcelFileToDatabaseJobLauncher excelFileToDatabaseJobLauncher;

	@RequestMapping("/hello")
	public String sayHello() {
		return "Hello !!";
	}
	@PostMapping("/uploadFile")
	public void uploadFile(@RequestParam(required = false) MultipartFile file) throws Exception {
		MyFileHolder myfile = new MyFileHolder();
		myfile.setFile(new SerialBlob(file.getBytes()));
	//	excelFileReader.readContents(file);
		FileMapper fmap = new FileMapper();
		fmap.setFile(file);
		//excelFileToDatabaseJobLauncher.launchXmlFileToDatabaseJob();
		FileCreators fc = new FileCreators();
		fc.writeFile(file);
		fileRepository.save(myfile);
	}
	
	@GetMapping("/process")
	public ResponseEntity<ArrayList<File>> processData() throws JobParametersInvalidException, JobExecutionAlreadyRunningException, JobRestartException, JobInstanceAlreadyCompleteException{
		
		ArrayList<File> files = excelFileToDatabaseJobLauncher.launchXmlFileToDatabaseJob();
		return new ResponseEntity<ArrayList<File>>(files, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/zip", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE,method=RequestMethod.POST)
	public String zipFiles(@RequestBody RequestPojo data ,HttpServletResponse response) throws IOException{
		String result = ZipUtils.createZipFolder(FileCreators.getResourcePath("pdfs").toString(),FileCreators.getResourcePath("public").toString());
	        Iterator<String> it = data.getData().iterator();
	        while(it.hasNext()){
	        		File file  = new File(it.next());
	        		file.delete();
	        }
	        
			return result;
	}
	
	@RequestMapping(value = "/FolderDownload", method=RequestMethod.GET)
	public String download(){
		
		File f = new File(FileCreators.getResourcePath("public").toString()+"/"+"Folder.zip");
		if(f.exists()){
			f.delete();
		}
		return "success";
	}
	
}