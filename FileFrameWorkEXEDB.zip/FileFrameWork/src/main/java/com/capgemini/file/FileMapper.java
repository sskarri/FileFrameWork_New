package com.capgemini.file;

import java.io.File;

import org.springframework.web.multipart.MultipartFile;

public class FileMapper {

	public FileMapper() {
		// TODO Auto-generated constructor stub
	}
	public MultipartFile getFile() {
		return file;
	}
	public void setFile(MultipartFile file2) {
		this.file = file;
	}
	private MultipartFile file;
	

}
