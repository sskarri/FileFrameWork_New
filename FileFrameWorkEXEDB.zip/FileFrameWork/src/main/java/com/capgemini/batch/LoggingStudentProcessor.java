package com.capgemini.batch;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.capgemini.file.FileCreators;
import com.capgemini.file.VelocityConfig;
import com.capgemini.model.BillingDTO;
import com.capgemini.model.StudentDTO;

/**
 * This custom {@code ItemProcessor} simply writes the information of the
 * processed student to the log and returns the processed object.
 *
 * @author Shyamsatyanarayan
 */
public class LoggingStudentProcessor implements ItemProcessor<BillingDTO, BillingDTO> {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoggingStudentProcessor.class);

	@Override
	public BillingDTO process(BillingDTO item) throws Exception {
		LOGGER.info("Processing Billing information: {}", item);
		Map<String, Object> model = new HashMap<String, Object>();
		double currBal = Double.parseDouble(item.getQty()) * Double.parseDouble(item.getRate());
		item.setCurrentBalance(String.valueOf(currBal));
		if (!StringUtils.isEmpty(item.getOldBalance())) {
			double total = currBal + Double.parseDouble(item.getOldBalance());
			item.setTotal(String.valueOf(total));
		} else {
			item.setTotal(String.valueOf(currBal));
		}
		model.put("item", item);
		VelocityConfig velocityConfig = new VelocityConfig();
		String html = velocityConfig.geFreeMarkerTemplateContent(model);
		FileCreators fileCreators = new FileCreators();
		fileCreators.writeFile(html,
				item.getCustomerName() + "_" + item.getCustomerId());

		return item;
	}
}
