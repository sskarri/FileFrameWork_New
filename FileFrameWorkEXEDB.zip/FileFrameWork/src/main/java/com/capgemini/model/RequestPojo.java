
package com.capgemini.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"data"
})
public class RequestPojo {

@JsonProperty("data")
private List<String> data = null;
/*@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();*/

@JsonProperty("data")
public List<String> getData() {
return data;
}

@JsonProperty("data")
public void setData(List<String> data) {
this.data = data;
}
/*
@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}*/

}